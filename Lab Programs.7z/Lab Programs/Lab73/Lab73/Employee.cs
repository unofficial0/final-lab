﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Lab73
{
    [AttributeUsage(AttributeTargets.Class ,AllowMultiple = true)]
    class Employee:Attribute
    {
        public int EmployeeId { get; set; }
        public string EmployeeName { get; set; }
        public double Salary { get; set; }
         public double PFAttribute{ get; set; }
        public Employee()
        {

        }
        public Employee(int employeeId,string employeeName,double salary,double pfAttribute)
        {
            this.EmployeeId = employeeId;
            this.EmployeeName = employeeName;
            this.Salary = salary;
            this.PFAttribute = pfAttribute;
        }
    }
}
