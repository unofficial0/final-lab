﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Lab42
{
    class Shape
    { 
      public virtual void WhoamI()
            {
                Console.WriteLine("I m Shape");
            }
        }


         class Triangle : Shape
        {
            public override void WhoamI()
            {
                Console.WriteLine("I m Triangle");
            }
        }


         class Circle : Shape
        {
            public override void WhoamI()
            {
                Console.WriteLine("I m Circle");
            }
        }
    }
