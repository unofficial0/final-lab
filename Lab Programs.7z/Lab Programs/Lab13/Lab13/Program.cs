﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Lab13
{
    class Program
    {
        static void Main(string[] args)
        {
            int num;
            Console.WriteLine("Enter a number");
            num = int.Parse(args[0]);
            switch(num)
            {
                case 1:
                    Console.WriteLine("One is Created");
                    break;
                case 2:
                    Console.WriteLine("Two is Created");
                    break;
                case 3:
                    Console.WriteLine("Three is Created");
                    break;
                case 4:
                    Console.WriteLine("Four is Created");
                    break;
                case 5:
                    Console.WriteLine("Five is Created");
                    break;
                default:
                    Console.WriteLine("Invalid Input");
                    break;
            }
        }
    }
}
