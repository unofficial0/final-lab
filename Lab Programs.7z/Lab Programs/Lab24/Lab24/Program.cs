﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Lab24
{
    class Program
    {
        static void Main(string[] args)
        {
            int ID = 0,  quantity;
            double price;
            string name;
            Console.WriteLine("ProductDetails are :");
            Console.WriteLine("Enter the Product ID:");
            ID = Convert.ToInt32(Console.ReadLine());
            Console.WriteLine("Enter the product name");
            name = Console.ReadLine();
            Console.WriteLine("Enter the price");
            price = Convert.ToDouble(Console.ReadLine());
            Console.WriteLine("Enter the quantity");
            quantity = Convert.ToInt32(Console.ReadLine());

            object obj = ID;
            object obj1 = name;
            object obj2 = price;
            object obj3 = quantity;

            int i=(int)obj;
            string j = (string)obj1;
            double k = (double)obj2;
            int l = (int)obj3;

            double m = k * l;

            Console.WriteLine("Product Details are : ");
            Console.WriteLine("Product ID:"+obj);
            Console.WriteLine("Product Name:" + obj1);
            Console.WriteLine("Price:" + obj2);
            Console.WriteLine("Quantity:" + obj3);

            Console.WriteLine("Amount Payable:"+m);
            Console.ReadKey();
        }
    }
}
