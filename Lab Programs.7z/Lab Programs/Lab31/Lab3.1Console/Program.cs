﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Participant;

namespace Lab3._1Console
{
    class Program
    {
        static void Main(string[] args)
        {
            try
            {
                Participant.Participant obj = new Participant.Participant();
                Console.WriteLine("-------Enter the Participant Details--------");
                Console.WriteLine("Enter the EmpId : ");
                obj.EmpId = Convert.ToInt32(Console.ReadLine());
                Console.WriteLine("Enter the Employee in Name : ");
                obj.Name = Console.ReadLine();
                Console.WriteLine("Enter the FoundationMarks : ");
                obj.FoundationMarks = Convert.ToInt32(Console.ReadLine());
                Console.WriteLine("Enter the webBasicMarks : ");
                obj.WebBasicMarks = Convert.ToInt32(Console.ReadLine());
                Console.WriteLine("Enter the DotNetMarks : ");
                obj.DotNetMarks = Convert.ToInt32(Console.ReadLine());

                obj.CalculateObtainedMarks();
                obj.CalculatePercentage();
                Console.WriteLine("EmpId {0},Name {1},FoundationMarks {2},DotNetMarks {3},WebBaiscMarks {4}",
                    obj.EmpId, obj.Name, obj.FoundationMarks, obj.DotNetMarks, obj.WebBasicMarks);
            }
            catch(InValidFoundationMarksException ex)
            {
                Console.WriteLine(ex.Message);
            }
            Console.ReadLine();
        }
        
    }
}
