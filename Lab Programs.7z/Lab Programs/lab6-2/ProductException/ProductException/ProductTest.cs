﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ProductException
{
    class ProductTest
    {
        static void Main(string[] args)
        {
            {
                DataEntryException de1 = new DataEntryException("Product ID must be greater than zero ");
                DataEntryException de2 = new DataEntryException("Product Name cannot be left blank ");
                DataEntryException de3 = new DataEntryException("Price of product must be greater than zero ");

                Console.WriteLine("Enter Number of Products:");
                int k = Convert.ToInt32(Console.ReadLine());

                Console.WriteLine("enter the product details:");
                ProductMock mock = new ProductMock();
                Console.WriteLine("enter the productId:");
                mock.ProductId1= Convert.ToInt32(Console.ReadLine());
                Console.WriteLine("enter the productname-");
                string name = Console.ReadLine();
                Console.WriteLine("enter the price-");
                double price = Convert.ToDouble(Console.ReadLine());
                
                
                

                try
                {
                    if (p.ProductId1 <= 0)
                    {
                        throw de1;

                    }
                    else
                    {
                        Console.WriteLine("product id is greater than zero");
                    }

                }
                catch (DataEntryException e)
                {

                    Console.WriteLine(e.Message);

                }
                try
                {
                    if (p.productName1 == "")
                    {
                        throw de2;

                    }
                    else
                    {
                        Console.WriteLine("product name is not blank");
                    }
                }
                catch (DataEntryException e)
                {

                    Console.WriteLine(e.Message);

                }
                try
                {
                    if (p.price1 >= 0)
                    {
                        throw de3;


                    }
                    else
                    {
                        Console.WriteLine("product price is not zero");
                    }

                }
                catch (DataEntryException e)
                {
                    Console.WriteLine(e.Message);

                }

                Console.ReadKey();










            }

        }
    }
}
