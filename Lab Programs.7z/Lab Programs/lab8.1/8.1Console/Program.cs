﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Collections;
using System.Text;
using System.Threading.Tasks;

namespace _8._1Console
{
    class Program
    {
        public static Hashtable RTODistrict = new Hashtable();
        static void Main(string[] args)
        {
            string choice1;
            do
            {
                Console.WriteLine("1. Add RTO record");
                Console.WriteLine("2. Delete record");
                Console.WriteLine("3. Get all Employee Details");
                Console.WriteLine("4. Search Employee");
                Console.WriteLine("5. No of Records");
                int choice = Int32.Parse(Console.ReadLine());
                switch (choice)
                {
                    case 1:
                        AddHashTable();
                        break;
                    case 2:
                        DeleteRecord();
                        break;
                    case 3:
                        DisplayRecords();
                        break;
                    case 4:
                        SearchRecord();
                        break;
                    case 5:
                        Count();
                        break;
                }
                Console.WriteLine("Do you want to contiue(y/n)?");
                choice1 = Console.ReadLine();
            } while ((choice1 == "y"));
            Console.Read();
        }

        public static void AddHashTable()
        {
            Console.WriteLine("Enter RTO Code :");
            string code = Console.ReadLine();
            Console.WriteLine("Enter district :");
            string district = Console.ReadLine();
            RTODistrict.Add(code, district);
        }

        static void DeleteRecord()
        {
            Console.WriteLine("Enter RTO Code to be removed:");
            string code1 = Console.ReadLine();
            RTODistrict.Remove(code1);
            Console.WriteLine("Record  has been removed");
        }

        static void DisplayRecords()

        {
            ICollection keys = RTODistrict.Keys;
            foreach (object obj in keys)
            {
                string code = (string)obj;
                string Name = (string)RTODistrict[code];
                Console.WriteLine("RTO code = {0} Name = {1}", code, Name);
            }
        }

        static void SearchRecord()
        {
            Console.WriteLine("Enter RTO Code to be searched:");
            string code = Console.ReadLine();
            ICollection collection = RTODistrict.Keys;
            foreach (Object obj in collection)
            {
                string code1 = (string)obj;
                if (code1 == code)
                {
                    string Name = (string)RTODistrict[code];
                    Console.WriteLine("RTO code = {0} Name = {1}", code, Name);
                }
                else
                {
                    Console.WriteLine("No record found");
                }
            }
        }

        static void Count()

        {
            
            int count = RTODistrict.Count;
            Console.WriteLine("No of elements" + count);
        }

    }
}
