﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.Serialization;
using System.Text;
using System.Threading.Tasks;

namespace Lab13_1
{
    [Serializable]
    class Contact
    {
        public string ContactName { get; set; }
        public double MobileNumber { get; set; }
        public Contact()
        {

        }
        public Contact(string ContactName,double MobileNumber)
        {
            this.ContactName = ContactName;
            this.MobileNumber = MobileNumber;
        }

        public override string ToString()
        {
            return $"{ContactName},{MobileNumber}";             //$"RollNo {RollNo}, Name {FullName}, FeesPaid {FeesPaid}, DOB {DOB}";            
        }

        //public void OnDeserialization(object sender)
        //{
        //    ContactName = "Student-" ;
        //}
    }
}
