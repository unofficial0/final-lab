﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Runtime.Serialization.Formatters.Binary;
using System.Text;
using System.Threading.Tasks;

namespace Lab13_1
{
    class Program
    {
        static void Main(string[] args)
        {
            string filePath = "Students.sser";

            List<Contact> contact = new List<Contact>
            {

                new Contact {ContactName="susmitha",MobileNumber=9712345678},
                //new Student { RollNo = 2, FullName = "Harshal", FeesPaid = 4700, DOB = new DateTime (1991, 3,17) },
                //new Student { RollNo = 3, FullName = "Kailash", FeesPaid = 3900, DOB = new DateTime (1983, 5,12) }
            };

            Serializecontact(filePath, contact);

            List<Contact> c_contact = Deserializecontact(filePath);
            foreach (var item in c_contact)
            {
                Console.WriteLine(item);
            }

            Console.ReadKey();
        }

        private static void Serializecontact(string filePath, List<Contact> contacts)
        {
            FileStream fileStream = new FileStream(filePath, FileMode.Create);
            BinaryFormatter binaryFormatter = new BinaryFormatter();
            binaryFormatter.Serialize(fileStream, contacts);
            
            fileStream.Close();
        }
        private static List<Contact> Deserializecontact(string filePath)
        {
            FileStream fileStream = new FileStream(filePath, FileMode.Open);
            BinaryFormatter binaryFormatter = new BinaryFormatter();
            List<Contact> contacts = (List<Contact>)binaryFormatter.Deserialize(fileStream);

            //ArrayList students = (ArrayList)soapFormatter.Deserialize(fileStream);
            fileStream.Close();
            return contacts;
        }
    }
    }

