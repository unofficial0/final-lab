﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;


namespace ABCException
{


    //[Serializable]
    //public class InvalidCreditLimitException : Exception
    //{
    //    public InvalidCreditLimitException() { }
    //    public InvalidCreditLimitException(string message) : base(message) { }

    //}

    [Serializable]
    public class InvalidCreditLimitException : Exception
    {
        public InvalidCreditLimitException() { }
        public InvalidCreditLimitException(string message) : base(message) { }
        public InvalidCreditLimitException(string message, Exception inner) : base(message, inner) { }
        protected InvalidCreditLimitException(
          System.Runtime.Serialization.SerializationInfo info,
          System.Runtime.Serialization.StreamingContext context) : base(info, context) { }
    }
}
