﻿using Guest_Entities;
using Guest_Exception;
using GuestHouse_BAL;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Guest_PL
{
    class Program
    {
        static void Main(string[] args)
        {
            int choice;
            do
            {
                PrintMenu();
                Console.WriteLine("Enter your Choice");
                choice = Convert.ToInt32(Console.ReadLine());
                switch (choice)
                {
                    case 1:
                        AddGuest();
                        break;
                    case 2:
                        ListAllGuests();
                        break;
                    case 3:
                        SearchGuestById();
                        break;
                    case 4:
                        UpdateGuest();
                        break;
                    case 5:
                        DeleteGuest();
                        break;
                    case 6:
                        SearchGuestByRelation();
                        break;
                    case 7:
                        return;
                        break;
                    default:
                        Console.WriteLine("Invalid Choice");
                        break;

                }
            } while (choice != -1);
        }

        private static void DeleteGuest()
        {
            try
            {
                int deleteGuestId;
                Console.WriteLine("Enter GuestId to Delete:");
                deleteGuestId = Convert.ToInt32(Console.ReadLine());
                Guest deleteGuest = GuestBAL.SearchGuestBL(deleteGuestId);
                if (deleteGuest != null)
                {
                    bool guestdeleted = GuestBAL.DeleteGuestBL(deleteGuestId);
                    if (guestdeleted)
                        Console.WriteLine("Guest Deleted");
                    else
                        Console.WriteLine("Guest not deleted");
                }
                else
                {
                    Console.WriteLine("No Guest Details Available");
                }
            }
            catch (GuestHouseException ex)
            {
                Console.WriteLine(ex.Message);
            }
        }

        private static void UpdateGuest()
        {
            try
            {
                int updateGuestId;
                Console.WriteLine("Enter Guestid to Update Details:");
                updateGuestId = Convert.ToInt32(Console.ReadLine());
                Guest updatedGuest = GuestBAL.SearchGuestBL(updateGuestId);
                if (updatedGuest != null)
                {
                    Console.WriteLine("Update Guest Name :");
                    updatedGuest.GuestName = Console.ReadLine();
                    Console.WriteLine("Update Guest Contact Number :");
                    updatedGuest.ContactNo = Console.ReadLine();
                    bool guestUpdated = GuestBAL.UpdateGuestBL(updatedGuest);
                    if (guestUpdated)
                    {
                        Console.WriteLine("Guest Details Updated");
                    }
                    else
                    {
                        Console.WriteLine("GuestDetails Not Updated");
                    }
                }
                else
                {
                    Console.WriteLine("No GuestDetails Available");
                }
            }
            catch (GuestHouseException ex)
            {
                Console.WriteLine(ex.Message);
            }
        }

        private static void SearchGuestById()
        {
            try
            {
                int searchGuestId;
                Console.WriteLine("Enter guestid to search :");
                searchGuestId = Convert.ToInt32(Console.ReadLine());
                Guest searchGuest = GuestBAL.SearchGuestBL(searchGuestId);
                if (searchGuest != null)
                {
                    Console.WriteLine("******************************************************************************");
                    Console.WriteLine("GuestID\t\tName\t\tPhoneNumber");
                    Console.WriteLine("******************************************************************************");
                    Console.WriteLine("{0}\t\t{1}\t\t{2}", searchGuest.GuestID, searchGuest.GuestName, searchGuest.ContactNo);
                    Console.WriteLine("******************************************************************************");

                }
                else
                {
                    Console.WriteLine("No Guest Details Available");
                }

            }
            catch (GuestHouseException ex)
            {
                Console.WriteLine(ex.Message);
            }
        }

        private static void SearchGuestByRelation()
        {
           
            try
            {
                Relation searchGuestRel;
                Console.WriteLine("Enter guest Relation to search :");
                searchGuestRel =(Relation)Convert.ToInt32(Console.ReadLine());
                Guest searchGuest = GuestBAL.SearchGuestByRelationBL(searchGuestRel);
                if (searchGuest != null)
                {
                    Console.WriteLine("******************************************************************************");
                    Console.WriteLine("GuestID\t\tName\t\tPhoneNumber");
                    Console.WriteLine("******************************************************************************");
                    Console.WriteLine("{0}\t\t{1}\t\t{2}", searchGuest.GuestID, searchGuest.GuestName, searchGuest.ContactNo);
                    Console.WriteLine("******************************************************************************");

                }
                else
                {
                    Console.WriteLine("No Guest Details Available");
                }

            }
            catch (GuestHouseException ex)
            {
                Console.WriteLine(ex.Message);
            }
        }

        private static void ListAllGuests()
        {
            try
            {
                List<Guest> guestList = GuestBAL.GetAllGuestBL();
                if (guestList != null)
                {
                    Console.WriteLine("******************************************************************************");
                    Console.WriteLine("GuestID\t\tName\t\tPhoneNumber");
                    Console.WriteLine("******************************************************************************");
                    foreach (Guest guest in guestList)
                    {
                        Console.WriteLine("{0}\t\t{1}\t\t{2}", guest.GuestID, guest.GuestName, guest.ContactNo);
                    }
                    Console.WriteLine("******************************************************************************");

                }
                else
                {
                    Console.WriteLine("No Guest Details Available");
                }
            }
            catch (GuestHouseException ex)
            {
                Console.WriteLine(ex.Message);
            }
        }

        private static void AddGuest()
        {
            try
            {
                Guest newGuest = new Guest();
                Console.WriteLine("Enter GuestID :");
                newGuest.GuestID = Convert.ToInt32(Console.ReadLine());
                Console.WriteLine("Enter Guest Name :");
                newGuest.GuestName = Console.ReadLine();
                Console.WriteLine("Enter PhoneNumber :");
                newGuest.ContactNo = Console.ReadLine();
                Console.WriteLine("Enter guest Relation :");
                newGuest.Relationship = (Relation)Convert.ToInt32(Console.ReadLine());
                bool guestAdded = GuestBAL.AddGuestBL(newGuest);
                if (guestAdded)
                    Console.WriteLine("Guest Added");
                else
                    Console.WriteLine("Guest not Added");
            }
            catch (GuestHouseException ex)
            {
                Console.WriteLine(ex.Message);
            }
        }

        private static void PrintMenu()
        {
            Console.WriteLine("\n***********Guest PhoneBook Menu***********");
            Console.WriteLine("1. Add Guest");
            Console.WriteLine("2. List All Guests");
            Console.WriteLine("3. Search Guest by ID");
            Console.WriteLine("4. Update Guest");
            Console.WriteLine("5. Delete Guest");
            Console.WriteLine("6. Search Guest by Relation");
            Console.WriteLine("7. Exit");
            Console.WriteLine("******************************************\n");

        }
    }

    
}
