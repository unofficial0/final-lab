﻿using Guest_Entities;
using Guest_Exception;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace GuestHouse_DAL
{
    public class Guest_DAL
    {
        public static List<Guest> guestList = new List<Guest>();

        public bool AddGuestDAL(Guest newGuest)
        {
            bool guestAdded = false;
            try
            {
                guestList.Add(newGuest);
                guestAdded = true;

            }
            catch (SystemException ex)
            {
                throw new GuestHouseException(ex.Message);
            }
            return guestAdded;
        }

        public List<Guest> GetAllGuestDAL()
        {
            return guestList;
        }

        public Guest SearchGuestDAL(int searchGuestId)
        {
            Guest searchGuest = null;
            try
            {
                searchGuest = guestList.Find(guest => guest.GuestID == searchGuestId);
            }
            catch (SystemException ex)
            {
                throw new GuestHouseException(ex.Message);
            }
            return searchGuest;
        }

        public Guest SearchGuestByRelationDAL(Relation rel)
        {
            Guest searchGuest = null;
            try
            {
                searchGuest = guestList.Find(guest => guest.Relationship == rel);
            }
            catch (SystemException ex)
            {
                throw new GuestHouseException(ex.Message);
            }
            return searchGuest;
        }

        public bool UpdateGuestDAL(Guest UpdateGuest)
        {
            bool guestUpdated = false;
            try
            {
                for (int i = 0; i < guestList.Count; i++)
                {
                    if (guestList[i].GuestID == UpdateGuest.GuestID)
                    {
                        UpdateGuest.GuestName = guestList[i].GuestName;
                        UpdateGuest.ContactNo = guestList[i].ContactNo;
                        guestUpdated = true;
                    }
                }
            }
            catch (SystemException ex)
            {
                throw new GuestHouseException(ex.Message);
            }
            return guestUpdated;
        }

        public bool DeleteGuestDAL(int deleteGuestId)
        {
            bool guestDeleted = false;
            try
            {
                Guest deleteGuest = guestList.Find(guest => guest.GuestID == deleteGuestId);
                if (deleteGuest != null)
                {
                    guestList.Remove(deleteGuest);
                    guestDeleted = true;
                }
            }
            catch (SystemException ex)
            {
                throw new GuestHouseException(ex.Message);
            }
            return guestDeleted;
        }

    }
}

