﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Guest_Exception
{


    [Serializable]
    public class GuestHouseException : Exception
    {
        public GuestHouseException() { }
        public GuestHouseException(string message) : base(message) { }
        public GuestHouseException(string message, Exception inner) : base(message, inner) { }
        protected GuestHouseException(
          System.Runtime.Serialization.SerializationInfo info,
          System.Runtime.Serialization.StreamingContext context) : base(info, context) { }
    }
}
