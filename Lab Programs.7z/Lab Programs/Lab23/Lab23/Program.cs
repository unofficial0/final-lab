﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Lab23
{
    class Program
    {
        static void Main(string[] args)
        {
            string[] cities = new string[5];
            Console.WriteLine("Enter the city names:");
            for (int i = 0; i < cities.Length; i++)
            {
                cities[i] = Console.ReadLine();
            }
            Console.WriteLine("City names are :");
            for (int i = 0; i < cities.Length; i++)
            {
                Console.WriteLine(cities[i]);
            }
            Console.ReadLine();
        }
    }
}
