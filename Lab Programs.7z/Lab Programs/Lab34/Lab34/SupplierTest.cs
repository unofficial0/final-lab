﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Lab34
{
    class SupplierTest
    {
        private int supplierID;
        private string supplierName;
        private string city;
        private string phoneNo;
        private string email;

        public int SupplierID { get => supplierID; set => supplierID = value; }
        public string SupplierName { get => supplierName; set => supplierName = value; }
        public string City { get => city; set => city = value; }
        public string PhoneNo { get => phoneNo; set => phoneNo = value; }
        public string Email { get => email; set => email = value; }

        public void AcceptDetails(int SupplierID,string SupplierName,string City,string PhoneNo,string email)
        {
            this.supplierID = SupplierID;
            this.supplierName = SupplierName;
            this.city = City;
            this.phoneNo = PhoneNo;
            this.email = Email;

        }
        public string DisplayDetails(int SupplierID, string SupplierName, string City, string PhoneNo, string email)
        {
            return string.Format("Supplier Id:" +SupplierID + "Supplier Name:" +SupplierName + "City:" + City + "phoneNumber:" + PhoneNo + "Email:" + Email);
            //return string.Format("SupplierID {0}  \n Name {1} \n  City {2} \n PhoneNumber {3} \n email ");
        }
    
    }
}